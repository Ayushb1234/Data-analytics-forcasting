from flask import Flask, jsonify
import pandas as pd
from prophet import Prophet
from sklearn.ensemble import IsolationForest

from flask_cors import CORS
app = Flask(__name__)
CORS(app)


# app = Flask(__name__)

# Load your actual CSV file
df = pd.read_csv(r"D:\course website\businessproject\backend\sales_data2.csv",encoding='ISO-8859-1', 
parse_dates=["Sale_Date"])


@app.route('/')
def home():
    return "✅ Flask backend is running. Use /forecast, /insights, /anomalies"

@app.route('/favicon.ico')
def favicon():
    return '', 204

@app.route('/insights')
def insights():
    insights = []
    grouped = df.groupby("Region")["Sales_Amount"].sum().reset_index()
    prev = grouped["Sales_Amount"].mean()

    for _, row in grouped.iterrows():
        change = (row["Sales_Amount"] - prev) / prev * 100
        if abs(change) > 10:
            direction = "increased" if change > 0 else "dropped"
            insights.append(f"Sales {direction} by {abs(change):.1f}% in {row['Region']}.")
    return jsonify(insights)

@app.route('/forecast')
def forecast():
    daily_sales = df.groupby("Sale_Date")["Sales_Amount"].sum().reset_index()
    daily_sales.columns = ["ds", "y"]
    model = Prophet()
    model.fit(daily_sales)
    future = model.make_future_dataframe(periods=15)
    forecast = model.predict(future)
    return jsonify({
        "labels": forecast["ds"].dt.strftime("%Y-%m-%d").tolist(),
        "values": forecast["yhat"].round(2).tolist()
    })

@app.route('/anomalies')
def anomalies():
    ts = df.groupby("Sale_Date")["Sales_Amount"].sum().reset_index()
    model = IsolationForest()
    ts["anomaly"] = model.fit_predict(ts[["Sales_Amount"]])
    outliers = ts[ts["anomaly"] == -1]
    return jsonify([
        {"date": str(r["Sale_Date"].date()), "reason": "Unusual sales value detected"}
        for _, r in outliers.iterrows()
    ])

if __name__ == '__main__':
    app.run(debug=True)

