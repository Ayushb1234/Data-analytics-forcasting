// 📁 FILE: App.jsx
import React, { useEffect, useState } from 'react';
import { Line } from 'react-chartjs-2';
import axios from 'axios';
import { Card, CardContent } from './components/ui/card';

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const App = () => {
  const [insights, setInsights] = useState([]);
  const [forecastData, setForecastData] = useState({ labels: [], values: [] });
  const [anomalies, setAnomalies] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/insights').then(res => setInsights(res.data));
    axios.get('http://localhost:5000/forecast').then(res => setForecastData(res.data));
    axios.get('http://localhost:5000/anomalies').then(res => setAnomalies(res.data));
  }, []);

  const chartData = {
    labels: forecastData.labels ?? [],
    datasets: [
      {
        label: 'Forecasted Sales',
        data: forecastData.values,
        fill: true,
        borderColor: 'rgba(75, 192, 192, 1)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        tension: 0.4,
        pointBackgroundColor: 'white',
        pointBorderColor: 'rgba(75, 192, 192, 1)',
        pointHoverRadius: 6
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        labels: {
          color: 'white',
          font: { size: 14, weight: 'bold' }
        }
      },
      title: {
        display: true,
        text: 'Sales Forecast Overview',
        color: 'white',
        font: { size: 18 }
      },
      tooltip: {
        backgroundColor: '#111827',
        titleColor: '#38bdf8',
        bodyColor: '#facc15'
      }
    },
    scales: {
      x: {
        type: 'category',
        ticks: { color: 'white' },
        grid: { color: 'rgba(255,255,255,0.1)' }
      },
      y: {
        ticks: { color: 'white' },
        grid: { color: 'rgba(255,255,255,0.1)' }
      }
    }
  };

  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6 bg-gray-900 min-h-screen text-white">
      <Card className="col-span-2 bg-gradient-to-r from-blue-800 via-purple-800 to-pink-800 shadow-xl">
        <CardContent>
          <h2 className="text-2xl font-bold mb-4 text-yellow-300">📊 AI-Powered Sales Forecast</h2>
          <Line data={chartData} options={chartOptions} />
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-r from-green-800 to-lime-700">
        <CardContent>
          <h2 className="text-xl font-bold mb-2 text-amber-300">🧠 Auto Insights</h2>
          <ul className="list-disc pl-5 space-y-1">
            {insights.map((insight, index) => (
              <li key={index} className="text-white hover:text-yellow-400">{insight}</li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-r from-red-800 to-pink-700">
        <CardContent>
          <h2 className="text-xl font-bold mb-2 text-white">⚠️ Anomalies Detected</h2>
          <ul className="list-disc pl-5 space-y-1">
            {anomalies.map((a, i) => (
              <li key={i} className="text-white hover:text-red-300">{a.date} → {a.reason}</li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};

export default App;
